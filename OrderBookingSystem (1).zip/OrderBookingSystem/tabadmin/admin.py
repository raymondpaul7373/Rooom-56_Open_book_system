from django.contrib import admin

# Register your models here.


from .models import Admin_tab

admin.site.register(Admin_tab)
admin.site.site_url = "../setdb"