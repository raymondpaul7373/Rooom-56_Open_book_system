from datetime import datetime

from django.db import models
from django.contrib.auth.models import User

class Admin_tab(models.Model):
    order_choices = (("Limit", "Limit"), ("Market", "Market"))
    status = (("Placed", "Placed"), ("Accepted", "Accepted"), ("Rejected","Rejected"))
    stock_name = models.CharField(max_length=25)
    order_qty = models.IntegerField()
    order_type = models.CharField(max_length=15, choices = order_choices)
    exec_qty = models.IntegerField()
    price = models.IntegerField()
    order_status = models.CharField(max_length=15,  choices = status)
    order_date = models.DateField()