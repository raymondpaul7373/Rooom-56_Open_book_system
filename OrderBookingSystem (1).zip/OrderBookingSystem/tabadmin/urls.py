from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.login),
    path('setdb', views.setdb),
    path('reg.html', views.reg),
    path('setuser', views.setuser),
    path('feed', views.feed)
]
