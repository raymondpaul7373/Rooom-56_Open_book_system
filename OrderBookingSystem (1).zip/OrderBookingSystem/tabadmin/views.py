from http.client import HTTPResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User

# Create your views here.

def setdb(request):
    return render(request, "adminscreen3.html")

def login(request):
    return render(request, "customer login.html")

def reg(request):
    return render(request, "reg.html")

def setuser(request):
    if request.method == "POST":
        fname = request.POST['fname']
        lname = request.POST['lname']
        uname = request.POST['uname']
        password  = request.POST['psw']
        is_su = 0
        em = request.POST['em']
        user = User(first_name = fname, last_name = lname, password = password, is_superuser = is_su, email =  em, username = uname)
        user.save()
        return redirect("http://localhost:8000")

def feed(request):
    if request.method == "POST":
        uname = request.POST["uname"]
        password = request.POST['pwd']
        if User.objects.filter(username = uname, password = password).exists():
            return render(request, "customerscreen1.html")
        else:
            return redirect("http://localhost:8000")